'use strict';

const express        = require('express');
const { mediumCache, getOrSet } = require('../services/cache');
const authMiddleware = require('../middleware/auth');
const { routeMessage, MODULES } = require('../agents/router/routerAgent');

// Agent import'ları
const { runForensicAnalysis }        = require('../agents/forensic/forensicAgent');
const { futureSelfChat, simulateScenario } = require('../agents/future-self/futureSelfAgent');
const { calculateHealthScore }       = require('../agents/health/healthAgent');
const { getMoneyPersona }            = require('../agents/persona/personaAgent');
const { chat }                       = require('../utils/gemini');
const { pool }                       = require('../db');

const router = express.Router();

// ── Tek Chat Endpoint — Tüm modülleri yönetir
router.post('/', authMiddleware, async (req, res, next) => {
  try {
    const { message } = req.body;

    if (!message?.trim()) {
      return res.status(400).json({ error: 'Mesaj boş olamaz' });
    }

    // 1. Router Agent — Hangi modüle gidecek?
    const route = await routeMessage(message);

    console.log(`🧭 Yönlendirme: ${route.module} (${(route.confidence * 100).toFixed(0)}%)`);

    // 2. İlgili agent'ı çağır
    let agentResponse;

    switch (route.module) {
      case 'forensic':
        agentResponse = await handleForensic(req.userId, message);
        break;

      case 'future-self':
        agentResponse = await handleFutureSelf(req.userId, message);
        break;

      case 'what-if':
        agentResponse = await handleWhatIf(req.userId, message);
        break;

      case 'intention':
        agentResponse = await handleIntention(req.userId, message);
        break;

      case 'health':
        agentResponse = await handleHealth(req.userId);
        break;

      case 'persona':
        agentResponse = await handlePersona(req.userId);
        break;

      default:
        agentResponse = await handleGeneral(req.userId, message);
        break;
    }

    // 3. Birleşik cevap döndür
    res.json({
      // Modül bilgisi — frontend'de etiket olarak gösterilecek
      routing: {
        module:      route.module,
        module_name: route.name,
        module_icon: route.icon,
        module_color: route.color,
        confidence:  route.confidence,
      },
      // Agent cevabı
      ...agentResponse,
    });

  } catch (err) { next(err); }
});

// ── Modül listesi (frontend'de buton/ikon göstermek için)
router.get('/modules', (req, res) => {
  const modules = Object.values(MODULES).filter(m => m.key !== 'general');
  res.json({ modules });
});

// ─────────────────────────────────────────────────────────────
// HANDLER FONKSİYONLARI
// ─────────────────────────────────────────────────────────────

// FORENSIC — Harcama analizi
const handleForensic = async (userId, message) => {
  const normalizedMsg = message.toLowerCase().trim();
  const cacheKey = `${userId}:forensic:${normalizedMsg}`;

  return await getOrSet(mediumCache, cacheKey, async () => {
    const now = new Date();
    const result = await runForensicAnalysis(
      userId,
      message,
      now.getMonth() + 1,
      now.getFullYear()
    );

    return {
      answer: result.answer || result.error,
      data: {
        patterns:        result.patterns || null,
        comparison:      result.comparison || null,
        recommendations: result.recommendations || null,
      },
    };
  });
};
// FUTURE SELF — Gelecekteki ben
const handleFutureSelf = async (userId, message) => {
  const result = await futureSelfChat(userId, message);

  return {
    answer: result.answer,
    data: {
      projection:     result.projection || null,
      persona_summary: result.persona_summary || null,
    },
  };
};

// WHAT-IF — Senaryo simülasyonu
const handleWhatIf = async (userId, message) => {
  // Mesajdan aylık değişim miktarını çıkar
  const amountMatch = message.match(/(\d+[\.,]?\d*)\s*(tl|lira|₺)/i);
  const amount = amountMatch 
    ? parseFloat(amountMatch[1].replace(',', '.')) 
    : 500; // default

  // Tasarruf mı harcama mı?
  const isExpense = /alsam|harcasam|versem|ödesem/i.test(message);
  const changeType = isExpense ? 'expense' : 'save';

  const result = await simulateScenario(
    userId,
    message,
    amount,
    changeType
  );

  return {
    answer: result.story || result.error,
    data: {
      scenario:    result.scenario || null,
      diff_5year:  result.diff_5year || null,
      milestones:  result.milestones || null,
      current:     result.current || null,
      simulated:   result.simulated || null,
    },
  };
};

// INTENTION — Söz aynası
const handleIntention = async (userId, message) => {
  // Kullanıcı söz veriyor mu yoksa durum soruyor mu?
  const isNewPromise = /yapacağım|söz|hedef|taahhüt|vaat|karar verdim/i.test(message);

  if (isNewPromise) {
    return {
      answer: 'Sözünü kaydettim! Söz Aynası modülünden detaylı hedef belirleyebilirsin. ' +
              'Hangi kategoride, ne kadar, hangi ay için hedef koymak istiyorsun?',
      data: {
        action: 'new_intention',
        suggestion: 'Söz Aynası modülüne yönlendir',
      },
    };
  }

  // Mevcut sözleri getir
  const now = new Date();
  const result = await pool.query(
    `SELECT * FROM intentions 
     WHERE user_id = $1 AND month = $2 AND year = $3
     ORDER BY created_at DESC`,
    [userId, now.getMonth() + 1, now.getFullYear()]
  );

  if (result.rows.length === 0) {
    return {
      answer: 'Bu ay henüz söz vermemişsin. ' +
              '"Bu ay 1500 TL tasarruf edeceğim" gibi bir hedef belirle!',
      data: { intentions: [] },
    };
  }

  const intentionList = result.rows.map(i => 
    `• ${i.goal_description} (${i.status})`
  ).join('\n');

  return {
    answer: `Bu ayki sözlerin:\n${intentionList}`,
    data: { intentions: result.rows },
  };
};

// HEALTH — Finansal sağlık
const handleHealth = async (userId) => {
  const result = await calculateHealthScore(userId);

  return {
    answer: `Finansal sağlık skorun: ${result.score}/100 (${result.grade})\n\n` +
            `${result.status}\n\n` +
            `Detaylar:\n` +
            `• Tasarruf: ${result.breakdown.saving.score}/100\n` +
            `• Söz Tutma: ${result.breakdown.promise.score}/100\n` +
            `• Harcama Trendi: ${result.breakdown.trend.score}/100\n` +
            `• Risk: ${result.breakdown.risk.score}/100\n\n` +
            `💡 ${result.advice}`,
    data: result,
  };
};

// PERSONA — Para kişiliği
const handlePersona = async (userId) => {
  const result = await getMoneyPersona(userId);

  if (result.error) {
    return { answer: result.error, data: null };
  }

  return {
    answer: `${result.icon} ${result.title}\n\n` +
            `${result.description}\n\n` +
            `Güçlü yanların: ${result.strengths.join(', ')}\n\n` +
            `Dikkat etmen gerekenler: ${result.weaknesses.join(', ')}\n\n` +
            `💡 ${result.advice}`,
    data: result,
  };
};

// GENERAL — Genel sohbet
const handleGeneral = async (userId, message) => {
  // Kullanıcı bilgisi
  const userResult = await pool.query(
    'SELECT name, monthly_income FROM users WHERE id = $1',
    [userId]
  );
  const user = userResult.rows[0];

  const prompt = `
Sen Finans Aynası'nın genel finans asistanısın.
Kullanıcının adı: ${user?.name || 'Kullanıcı'}
Aylık geliri: ${user?.monthly_income || 'Bilinmiyor'} TL

Kullanıcı sana şunu yazdı: "${message}"

KURALLAR:
1. Türkçe, samimi ve kısa cevap ver (100-150 kelime).
2. Finansal konularda yardımcı ol.
3. Kullanıcıyı doğru modüle yönlendir:
   - Harcama analizi istiyorsa → "Bunu Adli Muhasebeci modülüm detaylı analiz edebilir"
   - Gelecek soruyorsa → "Gelecekteki Ben modülümle konuşabilirsin"
   - Hedef koymak istiyorsa → "Söz Aynası modülünde hedef belirleyebilirsin"
4. Genel selamlaşmalara samimi cevap ver ve özellikleri tanıt.
5. Yazım hatalarını tolere et, bağlamdan anla.
`;

  const answer = await chat(prompt, 'flash');
  return { answer, data: null };
};

module.exports = router;